#ifndef _VJOY_PYTHON_H
#define _VJOY_PYTHON_H

#include "vjoy.h"

void vjoy_py_initialize();

#endif /* _VJOY_PYTHON_H */
