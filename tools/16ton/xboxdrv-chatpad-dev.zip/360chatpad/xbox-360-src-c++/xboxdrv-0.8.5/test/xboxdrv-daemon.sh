#!/bin/sh

xboxdrv --daemon \
 --next-controller \
    
 "$@"

# EOF #
