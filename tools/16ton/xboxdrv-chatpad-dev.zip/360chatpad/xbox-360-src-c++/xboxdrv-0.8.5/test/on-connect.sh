#!/bin/bash

exec notify-send -i gtk-connect "Controller connected:" "$3\n$2\n$1"

# EOF #

