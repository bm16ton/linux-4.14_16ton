import sys
import usb.core
import usb.util

# enable /disable kernel modules
# sudo rmmod uinput xpad xboxdrv / modprobe uinput

# find our device
dev = usb.core.find(idVendor=0x045e, idProduct=0x0719)

# was it found?
if dev is None:
    raise ValueError('Device not found')
    
# set the active configuration. With no arguments, the first
# configuration will be the active one
dev.set_configuration()

# iface 1-6 ends with: usb.core.USBError: [Errno 110] Operation timed out
# bEndpointAddress  0x01  EP 1 OUT ; bEndpointAddress  0x81  EP 1 IN 

epoint = 0x01
iface = 0

#enable wireless controller chatpad events: 00 00 0C 1B 00 00 00 00 00 00 00 00
#write(Endpointnumber, data, interfacenumber)
dev.write(epoint, '\0x00, \0x00, \0x0C, \0x1B, \0x00, \0x00, \0x00, \0x00, \0x00, \0x00, \0x00, \0x00', iface)

#while(0 == 0):
##You will have to send alternating 1E/1F keep-alive packets (every second or so, I guess) 
##to keep the chatpad events flowing: 00 00 0C 1E/1F 00 00 00 00 00 00 00 00
dev.write(epoint, '\0x00, \0x00, \0x0C, \0x1E, \0x00, \0x00, \0x00, \0x00, \0x00, \0x00, \0x00, \0x00', iface)

#enable backlight: 00 00 0C c 00 00 00 00 00 00 00 00
dev.write(epoint, '\0x00, \0x00, \0x0C, \0x0C, \0x00, \0x00, \0x00, \0x00, \0x00, \0x00, \0x00, \0x00', iface)
#enable backlight on keypress: 00 00 0C 1b 00 00 00 00 00 00 00 00
dev.write(epoint, '\0x00, \0x00, \0x0C, \0x1B, \0x00, \0x00, \0x00, \0x00, \0x00, \0x00, \0x00, \0x00', iface)	

dev.write(epoint, '\0x00, \0x00, \0x0C, \0x1F, \0x00, \0x00, \0x00, \0x00, \0x00, \0x00, \0x00, \0x00', iface)



