


##After doing this, you'll start getting 00 02 00 F0 event packets (the 02 signifying chatpad data). 
##The same data as the wired chatpad starts appearing at offset 0x18.

hinput = ep.read();

#on keypress "c" enable backlight: 00 00 0C c 00 00 00 00 00 00 00 00 
if (hinput == key_c)
{
dev.write(1, '\0x00, \0x00, \0x0C, \0xc, \0x00, \0x00, \0x00, \0x00, \0x00, \0x00, \0x00, \0x00')
}

#emulate keypress for event x, e.g:
#a = VK_KEY_A ; 0x41 
