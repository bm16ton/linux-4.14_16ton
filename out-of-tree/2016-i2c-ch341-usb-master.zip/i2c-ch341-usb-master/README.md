I2C-CH341-USB Linux kernel driver
=================
CH341 to i2c bus linux kernel driver. With this driver inserted to Linux kernel, you can write your code using the standard Linux I2C API.
## How to use it
```
make
insmod i2c-ch341-usb.ko
```
