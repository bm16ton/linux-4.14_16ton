# Wireless Driver Injection patches
Various Wireless Driver patches for Kali Linux.
* https://bugs.kali.org/view.php?id=4220

